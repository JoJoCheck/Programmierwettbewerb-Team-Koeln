import java.io.IOException;



public class Main 
{
	public static void main(String[] args) 
	{
		try 
		{
			new Wald("input_files/forest01.txt", "result_files/forest01.txt.out");
			new Wald("input_files/forest02.txt", "result_files/forest02.txt.out");
			new Wald("input_files/forest03.txt", "result_files/forest03.txt.out");
			new Wald("input_files/forest04.txt", "result_files/forest04.txt.out");
			new Wald("input_files/forest05.txt", "result_files/forest05.txt.out");
			new Wald("input_files/forest06.txt", "result_files/forest06.txt.out");
			new Wald("input_files/forest07.txt", "result_files/forest07.txt.out");
			new Wald("input_files/forest08.txt", "result_files/forest08.txt.out");
			new Wald("input_files/forest09.txt", "result_files/forest09.txt.out");
			new Wald("input_files/forest10.txt", "result_files/forest10.txt.out");
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
}
