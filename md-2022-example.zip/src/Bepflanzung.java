public class Bepflanzung 
{
	// Ort der Pflanzung
	Punkt p;
	// Index des Baums, der gepflanzt wird
	int i;
	
	public Bepflanzung (Punkt p, int i)
	{
		this.p = p;
		this.i = i;
	}
	
	public void gibAus (double [] pflanzgut)
	{
		System.out.printf("x=%.15f, y=%.15f, r=%.15f\n", p.x, p.y, pflanzgut[i]);
	}
}
