public class Punkt 
{
	double x, y;
	
	public Punkt(double x, double y) 
	{
		this.x = x;
		this.y = y;
	}

	public double berechneAbstandZuPunkt (Punkt p)
	{
		return Math.sqrt(Math.pow(x - p.x, 2) + Math.pow(y - p.y, 2));
	}
}
