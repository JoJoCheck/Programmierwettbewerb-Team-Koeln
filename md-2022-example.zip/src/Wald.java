import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;

public class Wald 
{
	private Random random = new Random();
	private String name;
	private String filename;
	double breite, tiefe;
	double[] radien;
	String[] names;
	private List<Bepflanzung> aktBepflanzung = new ArrayList<Bepflanzung>();
	private static final double EPSILON = 1e-10;
		
	private void readInput(String inputFilename) throws IOException {
		Scanner scanner = new Scanner(new File(inputFilename));
		name = scanner.nextLine();								// erste Zeile: Name	
		Scanner lineScanner = new Scanner(scanner.nextLine()); 	// zweite Zeile: Breite, Tiefe
		breite = lineScanner.nextDouble();
		tiefe = lineScanner.nextDouble();
		lineScanner.close();
		
		// ab dritter Zeile: Pflanzgut
		ArrayList<Double> list = new ArrayList<Double>();
		ArrayList<String> listNames = new ArrayList<String>();
		while (scanner.hasNextLine()) {
			list.add(scanner.nextDouble());
			listNames.add(scanner.nextLine());
		}
		radien = new double [list.size()];
		names = new String [list.size()];
		for (int i = 0; i < list.size(); i++) {
			radien[i] = list.get(i);
			names[i] = listNames.get(i);
		}
		scanner.close();
	}
	
	private boolean zufallBepflanzung() {
		double x = random.nextDouble() * breite;
		double y = random.nextDouble() * tiefe;
		int id = random.nextInt(radien.length);

		Punkt p = new Punkt(x,y);
		Bepflanzung b = new Bepflanzung(p, id);
		
		if (testRadius(b)) {
			aktBepflanzung.add(b);
			return true;
		}

		return false;
	}

	private boolean testRadius(Bepflanzung ref) {
		Punkt p = ref.p;
		int nrPflanzgut = ref.i;

		if (p.x - radien[nrPflanzgut] < 0 || p.x + radien[nrPflanzgut] > breite
			|| p.y - radien[nrPflanzgut] < 0 || p.y + radien[nrPflanzgut] > tiefe)
				return false;
		
		for (Bepflanzung b : aktBepflanzung) {
			if (p.berechneAbstandZuPunkt(b.p) < radien[b.i] + radien[nrPflanzgut] - EPSILON) {
				if (ref != b) {
					return false;
				}
			}
		}
		return true;
	}
	
	public Wald(String inputFilename, String outputFilename) throws IOException 
	{
		System.out.println("processing " + inputFilename + " into " + outputFilename);
		filename = inputFilename;
		readInput(inputFilename);

		int fail = 0;
		while (fail < 400) {
			if (zufallBepflanzung()) 
				fail = 0;
			else 
				fail++;
		}

		gibAus(new FileWriter(outputFilename));
	}
	
	private void gibAus (OutputStreamWriter osw) throws IOException
	{
		for (Bepflanzung b : aktBepflanzung) {
			osw.write(b.p.x + " " + b.p.y + " " + radien[b.i] + " " + b.i + System.lineSeparator());
		}
		osw.close();
	}
}
