rm -f md2022.jar
rm -f src/*.class
